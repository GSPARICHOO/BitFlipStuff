gdjs.lvl3Code = {};
gdjs.lvl3Code.localVariables = [];
gdjs.lvl3Code.idToCallbackMap = new Map();
gdjs.lvl3Code.GDPlayerSpriteObjects1= [];
gdjs.lvl3Code.GDPlayerSpriteObjects2= [];
gdjs.lvl3Code.GDPlayerSpriteObjects3= [];
gdjs.lvl3Code.GDNewSpriteObjects1= [];
gdjs.lvl3Code.GDNewSpriteObjects2= [];
gdjs.lvl3Code.GDNewSpriteObjects3= [];
gdjs.lvl3Code.GDCollisionBlockObjects1= [];
gdjs.lvl3Code.GDCollisionBlockObjects2= [];
gdjs.lvl3Code.GDCollisionBlockObjects3= [];
gdjs.lvl3Code.GDNewTileMapObjects1= [];
gdjs.lvl3Code.GDNewTileMapObjects2= [];
gdjs.lvl3Code.GDNewTileMapObjects3= [];
gdjs.lvl3Code.GDFrameInterfaceObjects1= [];
gdjs.lvl3Code.GDFrameInterfaceObjects2= [];
gdjs.lvl3Code.GDFrameInterfaceObjects3= [];
gdjs.lvl3Code.GDHPInterfaceObjects1= [];
gdjs.lvl3Code.GDHPInterfaceObjects2= [];
gdjs.lvl3Code.GDHPInterfaceObjects3= [];
gdjs.lvl3Code.GDScoreInterfaceObjects1= [];
gdjs.lvl3Code.GDScoreInterfaceObjects2= [];
gdjs.lvl3Code.GDScoreInterfaceObjects3= [];
gdjs.lvl3Code.GDKeyInterfaceObjects1= [];
gdjs.lvl3Code.GDKeyInterfaceObjects2= [];
gdjs.lvl3Code.GDKeyInterfaceObjects3= [];
gdjs.lvl3Code.GDHPTextObjects1= [];
gdjs.lvl3Code.GDHPTextObjects2= [];
gdjs.lvl3Code.GDHPTextObjects3= [];
gdjs.lvl3Code.GDScoreTextObjects1= [];
gdjs.lvl3Code.GDScoreTextObjects2= [];
gdjs.lvl3Code.GDScoreTextObjects3= [];
gdjs.lvl3Code.GDDoorObjects1= [];
gdjs.lvl3Code.GDDoorObjects2= [];
gdjs.lvl3Code.GDDoorObjects3= [];
gdjs.lvl3Code.GDKey2Objects1= [];
gdjs.lvl3Code.GDKey2Objects2= [];
gdjs.lvl3Code.GDKey2Objects3= [];
gdjs.lvl3Code.GDSpawnPointObjects1= [];
gdjs.lvl3Code.GDSpawnPointObjects2= [];
gdjs.lvl3Code.GDSpawnPointObjects3= [];
gdjs.lvl3Code.GDStartLvl1Objects1= [];
gdjs.lvl3Code.GDStartLvl1Objects2= [];
gdjs.lvl3Code.GDStartLvl1Objects3= [];
gdjs.lvl3Code.GDStartLvl2Objects1= [];
gdjs.lvl3Code.GDStartLvl2Objects2= [];
gdjs.lvl3Code.GDStartLvl2Objects3= [];
gdjs.lvl3Code.GDStartLvl3Objects1= [];
gdjs.lvl3Code.GDStartLvl3Objects2= [];
gdjs.lvl3Code.GDStartLvl3Objects3= [];
gdjs.lvl3Code.GD_9595_9595_9595Objects1= [];
gdjs.lvl3Code.GD_9595_9595_9595Objects2= [];
gdjs.lvl3Code.GD_9595_9595_9595Objects3= [];
gdjs.lvl3Code.GD_9595_9595_95952Objects1= [];
gdjs.lvl3Code.GD_9595_9595_95952Objects2= [];
gdjs.lvl3Code.GD_9595_9595_95952Objects3= [];


gdjs.lvl3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].setAnimationFrame(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].setAnimationFrame(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects1.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects1[k] = gdjs.lvl3Code.GDPlayerSpriteObjects1[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDPlayerSpriteObjects1 */
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects1.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


};gdjs.lvl3Code.asyncCallback11520612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl3Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects3);

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.lvl3Code.GDSpawnPointObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.lvl3Code.GDPlayerSpriteObjects3.length ;i < len;++i) {
    gdjs.lvl3Code.GDPlayerSpriteObjects3[i].setPosition((( gdjs.lvl3Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl3Code.GDSpawnPointObjects3[0].getPointX("")),(( gdjs.lvl3Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl3Code.GDSpawnPointObjects3[0].getPointY("")));
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-mechanical-crate-pick-up-3154.wav", false, 100, 1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-casino-bling-achievement-2067.wav", false, 100, 1);
}
gdjs.lvl3Code.localVariables.length = 0;
}
gdjs.lvl3Code.idToCallbackMap.set(11520612, gdjs.lvl3Code.asyncCallback11520612);
gdjs.lvl3Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl3Code.localVariables);
for (const obj of gdjs.lvl3Code.GDPlayerSpriteObjects2) asyncObjectsList.addObject("PlayerSprite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.lvl3Code.asyncCallback11520612(runtimeScene, asyncObjectsList)), 11520612, asyncObjectsList);
}
}

}


};gdjs.lvl3Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11520068);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl3Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.lvl3Code.asyncCallback11522684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl3Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}
gdjs.lvl3Code.localVariables.length = 0;
}
gdjs.lvl3Code.idToCallbackMap.set(11522684, gdjs.lvl3Code.asyncCallback11522684);
gdjs.lvl3Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl3Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.lvl3Code.asyncCallback11522684(runtimeScene, asyncObjectsList)), 11522684, asyncObjectsList);
}
}

}


};gdjs.lvl3Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDPlayerSpriteObjects2[i].getY() > 355 ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDPlayerSpriteObjects2[k] = gdjs.lvl3Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl3Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-player-losing-or-failing-2042.wav", false, 100, 1);
}

{ //Subevents
gdjs.lvl3Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl3Code.GDPlayerSpriteObjects2});
gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDScoreInterfaceObjects2Objects = Hashtable.newFrom({"ScoreInterface": gdjs.lvl3Code.GDScoreInterfaceObjects2});
gdjs.lvl3Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreInterface"), gdjs.lvl3Code.GDScoreInterfaceObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDScoreInterfaceObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDScoreInterfaceObjects2 */
{for(var i = 0, len = gdjs.lvl3Code.GDScoreInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDScoreInterfaceObjects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-winning-a-coin-video-game-2069.wav", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-video-game-health-recharge-2837.wav", false, 100, 1);
}
}

}


};gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl3Code.GDPlayerSpriteObjects2});
gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDKey2Objects2Objects = Hashtable.newFrom({"Key2": gdjs.lvl3Code.GDKey2Objects2});
gdjs.lvl3Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11528692);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(true);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 100, 1);
}
}

}


};gdjs.lvl3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl3Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDKey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl3Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl3Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl3Code.GDKeyInterfaceObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);
{for(var i = 0, len = gdjs.lvl3Code.GDKey2Objects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDKey2Objects2[i].setPosition((( gdjs.lvl3Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl3Code.GDPlayerSpriteObjects2[0].getCenterXInScene()) - 8,(( gdjs.lvl3Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl3Code.GDPlayerSpriteObjects2[0].getCenterYInScene()) - 4);
}
}
{for(var i = 0, len = gdjs.lvl3Code.GDKeyInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl3Code.GDKeyInterfaceObjects2[i].setColor("255;255;255");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11530828);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl3Code.GDKeyInterfaceObjects1);
{for(var i = 0, len = gdjs.lvl3Code.GDKeyInterfaceObjects1.length ;i < len;++i) {
    gdjs.lvl3Code.GDKeyInterfaceObjects1[i].setColor("35;35;46");
}
}
}

}


};gdjs.lvl3Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.lvl3Code.GDPlayerSpriteObjects2.length !== 0 ? gdjs.lvl3Code.GDPlayerSpriteObjects2[0] : null), true, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, -476, 80, 1434, 355, "", 0);
}
}

}


};gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects1Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl3Code.GDPlayerSpriteObjects1});
gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.lvl3Code.GDDoorObjects1});
gdjs.lvl3Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.lvl3Code.GDDoorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl3Code.GDDoorObjects1.length;i<l;++i) {
    if ( gdjs.lvl3Code.GDDoorObjects1[i].getBehavior("Animation").getAnimationName() == "Opened" ) {
        isConditionTrue_0 = true;
        gdjs.lvl3Code.GDDoorObjects1[k] = gdjs.lvl3Code.GDDoorObjects1[i];
        ++k;
    }
}
gdjs.lvl3Code.GDDoorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl4", false);
}
}

}


};gdjs.lvl3Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}
}

}


{


gdjs.lvl3Code.eventsList0(runtimeScene);
}


{


gdjs.lvl3Code.eventsList4(runtimeScene);
}


{


gdjs.lvl3Code.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HPText"), gdjs.lvl3Code.GDHPTextObjects1);
{for(var i = 0, len = gdjs.lvl3Code.GDHPTextObjects1.length ;i < len;++i) {
    gdjs.lvl3Code.GDHPTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.lvl3Code.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.lvl3Code.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.lvl3Code.GDScoreTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


gdjs.lvl3Code.eventsList7(runtimeScene);
}


{


gdjs.lvl3Code.eventsList8(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11338844);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UserInterface", 0, 0, 0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "inono777-game-8-bit-399898.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.lvl3Code.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl3Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDPlayerSpriteObjects1Objects, gdjs.lvl3Code.mapOfGDgdjs_9546lvl3Code_9546GDDoorObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl3Code.GDDoorObjects1 */
{for(var i = 0, len = gdjs.lvl3Code.GDDoorObjects1.length ;i < len;++i) {
    gdjs.lvl3Code.GDDoorObjects1[i].getBehavior("Animation").setAnimationName("Opened");
}
}

{ //Subevents
gdjs.lvl3Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.lvl3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl3Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl3Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDHPTextObjects1.length = 0;
gdjs.lvl3Code.GDHPTextObjects2.length = 0;
gdjs.lvl3Code.GDHPTextObjects3.length = 0;
gdjs.lvl3Code.GDScoreTextObjects1.length = 0;
gdjs.lvl3Code.GDScoreTextObjects2.length = 0;
gdjs.lvl3Code.GDScoreTextObjects3.length = 0;
gdjs.lvl3Code.GDDoorObjects1.length = 0;
gdjs.lvl3Code.GDDoorObjects2.length = 0;
gdjs.lvl3Code.GDDoorObjects3.length = 0;
gdjs.lvl3Code.GDKey2Objects1.length = 0;
gdjs.lvl3Code.GDKey2Objects2.length = 0;
gdjs.lvl3Code.GDKey2Objects3.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects3.length = 0;

gdjs.lvl3Code.eventsList10(runtimeScene);
gdjs.lvl3Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl3Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl3Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl3Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl3Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl3Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl3Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl3Code.GDHPTextObjects1.length = 0;
gdjs.lvl3Code.GDHPTextObjects2.length = 0;
gdjs.lvl3Code.GDHPTextObjects3.length = 0;
gdjs.lvl3Code.GDScoreTextObjects1.length = 0;
gdjs.lvl3Code.GDScoreTextObjects2.length = 0;
gdjs.lvl3Code.GDScoreTextObjects3.length = 0;
gdjs.lvl3Code.GDDoorObjects1.length = 0;
gdjs.lvl3Code.GDDoorObjects2.length = 0;
gdjs.lvl3Code.GDDoorObjects3.length = 0;
gdjs.lvl3Code.GDKey2Objects1.length = 0;
gdjs.lvl3Code.GDKey2Objects2.length = 0;
gdjs.lvl3Code.GDKey2Objects3.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl3Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl3Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl3Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl3Code.GD_9595_9595_95952Objects3.length = 0;


return;

}

gdjs['lvl3Code'] = gdjs.lvl3Code;
