gdjs.InitialMenuCode = {};
gdjs.InitialMenuCode.localVariables = [];
gdjs.InitialMenuCode.idToCallbackMap = new Map();
gdjs.InitialMenuCode.GDInitialButtonObjects1= [];
gdjs.InitialMenuCode.GDInitialButtonObjects2= [];
gdjs.InitialMenuCode.GDMouseArrowObjects1= [];
gdjs.InitialMenuCode.GDMouseArrowObjects2= [];
gdjs.InitialMenuCode.GDSTARTbuttonObjects1= [];
gdjs.InitialMenuCode.GDSTARTbuttonObjects2= [];
gdjs.InitialMenuCode.GDNewTextObjects1= [];
gdjs.InitialMenuCode.GDNewTextObjects2= [];
gdjs.InitialMenuCode.GDNewText2Objects1= [];
gdjs.InitialMenuCode.GDNewText2Objects2= [];
gdjs.InitialMenuCode.GDNewSprite2Objects1= [];
gdjs.InitialMenuCode.GDNewSprite2Objects2= [];
gdjs.InitialMenuCode.GDPlayerSpriteObjects1= [];
gdjs.InitialMenuCode.GDPlayerSpriteObjects2= [];
gdjs.InitialMenuCode.GDNewSpriteObjects1= [];
gdjs.InitialMenuCode.GDNewSpriteObjects2= [];
gdjs.InitialMenuCode.GDCollisionBlockObjects1= [];
gdjs.InitialMenuCode.GDCollisionBlockObjects2= [];
gdjs.InitialMenuCode.GDNewTileMapObjects1= [];
gdjs.InitialMenuCode.GDNewTileMapObjects2= [];
gdjs.InitialMenuCode.GDFrameInterfaceObjects1= [];
gdjs.InitialMenuCode.GDFrameInterfaceObjects2= [];
gdjs.InitialMenuCode.GDHPInterfaceObjects1= [];
gdjs.InitialMenuCode.GDHPInterfaceObjects2= [];
gdjs.InitialMenuCode.GDScoreInterfaceObjects1= [];
gdjs.InitialMenuCode.GDScoreInterfaceObjects2= [];
gdjs.InitialMenuCode.GDKeyInterfaceObjects1= [];
gdjs.InitialMenuCode.GDKeyInterfaceObjects2= [];
gdjs.InitialMenuCode.GDHPTextObjects1= [];
gdjs.InitialMenuCode.GDHPTextObjects2= [];
gdjs.InitialMenuCode.GDScoreTextObjects1= [];
gdjs.InitialMenuCode.GDScoreTextObjects2= [];
gdjs.InitialMenuCode.GDDoorObjects1= [];
gdjs.InitialMenuCode.GDDoorObjects2= [];
gdjs.InitialMenuCode.GDKey2Objects1= [];
gdjs.InitialMenuCode.GDKey2Objects2= [];
gdjs.InitialMenuCode.GDSpawnPointObjects1= [];
gdjs.InitialMenuCode.GDSpawnPointObjects2= [];
gdjs.InitialMenuCode.GDStartLvl1Objects1= [];
gdjs.InitialMenuCode.GDStartLvl1Objects2= [];
gdjs.InitialMenuCode.GDStartLvl2Objects1= [];
gdjs.InitialMenuCode.GDStartLvl2Objects2= [];
gdjs.InitialMenuCode.GDStartLvl3Objects1= [];
gdjs.InitialMenuCode.GDStartLvl3Objects2= [];
gdjs.InitialMenuCode.GD_9595_9595_9595Objects1= [];
gdjs.InitialMenuCode.GD_9595_9595_9595Objects2= [];
gdjs.InitialMenuCode.GD_9595_9595_95952Objects1= [];
gdjs.InitialMenuCode.GD_9595_9595_95952Objects2= [];


gdjs.InitialMenuCode.mapOfGDgdjs_9546InitialMenuCode_9546GDSTARTbuttonObjects1Objects = Hashtable.newFrom({"STARTbutton": gdjs.InitialMenuCode.GDSTARTbuttonObjects1});
gdjs.InitialMenuCode.mapOfGDgdjs_9546InitialMenuCode_9546GDSTARTbuttonObjects1Objects = Hashtable.newFrom({"STARTbutton": gdjs.InitialMenuCode.GDSTARTbuttonObjects1});
gdjs.InitialMenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("STARTbutton"), gdjs.InitialMenuCode.GDSTARTbuttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InitialMenuCode.mapOfGDgdjs_9546InitialMenuCode_9546GDSTARTbuttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11229780);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-casino-bling-achievement-2067.wav", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("STARTbutton"), gdjs.InitialMenuCode.GDSTARTbuttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InitialMenuCode.mapOfGDgdjs_9546InitialMenuCode_9546GDSTARTbuttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl1", false);
}
}

}


};

gdjs.InitialMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.InitialMenuCode.GDInitialButtonObjects1.length = 0;
gdjs.InitialMenuCode.GDInitialButtonObjects2.length = 0;
gdjs.InitialMenuCode.GDMouseArrowObjects1.length = 0;
gdjs.InitialMenuCode.GDMouseArrowObjects2.length = 0;
gdjs.InitialMenuCode.GDSTARTbuttonObjects1.length = 0;
gdjs.InitialMenuCode.GDSTARTbuttonObjects2.length = 0;
gdjs.InitialMenuCode.GDNewTextObjects1.length = 0;
gdjs.InitialMenuCode.GDNewTextObjects2.length = 0;
gdjs.InitialMenuCode.GDNewText2Objects1.length = 0;
gdjs.InitialMenuCode.GDNewText2Objects2.length = 0;
gdjs.InitialMenuCode.GDNewSprite2Objects1.length = 0;
gdjs.InitialMenuCode.GDNewSprite2Objects2.length = 0;
gdjs.InitialMenuCode.GDPlayerSpriteObjects1.length = 0;
gdjs.InitialMenuCode.GDPlayerSpriteObjects2.length = 0;
gdjs.InitialMenuCode.GDNewSpriteObjects1.length = 0;
gdjs.InitialMenuCode.GDNewSpriteObjects2.length = 0;
gdjs.InitialMenuCode.GDCollisionBlockObjects1.length = 0;
gdjs.InitialMenuCode.GDCollisionBlockObjects2.length = 0;
gdjs.InitialMenuCode.GDNewTileMapObjects1.length = 0;
gdjs.InitialMenuCode.GDNewTileMapObjects2.length = 0;
gdjs.InitialMenuCode.GDFrameInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDFrameInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDHPInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDHPInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDScoreInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDScoreInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDKeyInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDKeyInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDHPTextObjects1.length = 0;
gdjs.InitialMenuCode.GDHPTextObjects2.length = 0;
gdjs.InitialMenuCode.GDScoreTextObjects1.length = 0;
gdjs.InitialMenuCode.GDScoreTextObjects2.length = 0;
gdjs.InitialMenuCode.GDDoorObjects1.length = 0;
gdjs.InitialMenuCode.GDDoorObjects2.length = 0;
gdjs.InitialMenuCode.GDKey2Objects1.length = 0;
gdjs.InitialMenuCode.GDKey2Objects2.length = 0;
gdjs.InitialMenuCode.GDSpawnPointObjects1.length = 0;
gdjs.InitialMenuCode.GDSpawnPointObjects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl1Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl1Objects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl2Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl2Objects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl3Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl3Objects2.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_95952Objects2.length = 0;

gdjs.InitialMenuCode.eventsList0(runtimeScene);
gdjs.InitialMenuCode.GDInitialButtonObjects1.length = 0;
gdjs.InitialMenuCode.GDInitialButtonObjects2.length = 0;
gdjs.InitialMenuCode.GDMouseArrowObjects1.length = 0;
gdjs.InitialMenuCode.GDMouseArrowObjects2.length = 0;
gdjs.InitialMenuCode.GDSTARTbuttonObjects1.length = 0;
gdjs.InitialMenuCode.GDSTARTbuttonObjects2.length = 0;
gdjs.InitialMenuCode.GDNewTextObjects1.length = 0;
gdjs.InitialMenuCode.GDNewTextObjects2.length = 0;
gdjs.InitialMenuCode.GDNewText2Objects1.length = 0;
gdjs.InitialMenuCode.GDNewText2Objects2.length = 0;
gdjs.InitialMenuCode.GDNewSprite2Objects1.length = 0;
gdjs.InitialMenuCode.GDNewSprite2Objects2.length = 0;
gdjs.InitialMenuCode.GDPlayerSpriteObjects1.length = 0;
gdjs.InitialMenuCode.GDPlayerSpriteObjects2.length = 0;
gdjs.InitialMenuCode.GDNewSpriteObjects1.length = 0;
gdjs.InitialMenuCode.GDNewSpriteObjects2.length = 0;
gdjs.InitialMenuCode.GDCollisionBlockObjects1.length = 0;
gdjs.InitialMenuCode.GDCollisionBlockObjects2.length = 0;
gdjs.InitialMenuCode.GDNewTileMapObjects1.length = 0;
gdjs.InitialMenuCode.GDNewTileMapObjects2.length = 0;
gdjs.InitialMenuCode.GDFrameInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDFrameInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDHPInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDHPInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDScoreInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDScoreInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDKeyInterfaceObjects1.length = 0;
gdjs.InitialMenuCode.GDKeyInterfaceObjects2.length = 0;
gdjs.InitialMenuCode.GDHPTextObjects1.length = 0;
gdjs.InitialMenuCode.GDHPTextObjects2.length = 0;
gdjs.InitialMenuCode.GDScoreTextObjects1.length = 0;
gdjs.InitialMenuCode.GDScoreTextObjects2.length = 0;
gdjs.InitialMenuCode.GDDoorObjects1.length = 0;
gdjs.InitialMenuCode.GDDoorObjects2.length = 0;
gdjs.InitialMenuCode.GDKey2Objects1.length = 0;
gdjs.InitialMenuCode.GDKey2Objects2.length = 0;
gdjs.InitialMenuCode.GDSpawnPointObjects1.length = 0;
gdjs.InitialMenuCode.GDSpawnPointObjects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl1Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl1Objects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl2Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl2Objects2.length = 0;
gdjs.InitialMenuCode.GDStartLvl3Objects1.length = 0;
gdjs.InitialMenuCode.GDStartLvl3Objects2.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.InitialMenuCode.GD_9595_9595_95952Objects2.length = 0;


return;

}

gdjs['InitialMenuCode'] = gdjs.InitialMenuCode;
