gdjs.lvl5Code = {};
gdjs.lvl5Code.localVariables = [];
gdjs.lvl5Code.idToCallbackMap = new Map();
gdjs.lvl5Code.GDNewTextObjects1= [];
gdjs.lvl5Code.GDNewTextObjects2= [];
gdjs.lvl5Code.GDNewTextObjects3= [];
gdjs.lvl5Code.GDPlayerSpriteObjects1= [];
gdjs.lvl5Code.GDPlayerSpriteObjects2= [];
gdjs.lvl5Code.GDPlayerSpriteObjects3= [];
gdjs.lvl5Code.GDNewSpriteObjects1= [];
gdjs.lvl5Code.GDNewSpriteObjects2= [];
gdjs.lvl5Code.GDNewSpriteObjects3= [];
gdjs.lvl5Code.GDCollisionBlockObjects1= [];
gdjs.lvl5Code.GDCollisionBlockObjects2= [];
gdjs.lvl5Code.GDCollisionBlockObjects3= [];
gdjs.lvl5Code.GDNewTileMapObjects1= [];
gdjs.lvl5Code.GDNewTileMapObjects2= [];
gdjs.lvl5Code.GDNewTileMapObjects3= [];
gdjs.lvl5Code.GDFrameInterfaceObjects1= [];
gdjs.lvl5Code.GDFrameInterfaceObjects2= [];
gdjs.lvl5Code.GDFrameInterfaceObjects3= [];
gdjs.lvl5Code.GDHPInterfaceObjects1= [];
gdjs.lvl5Code.GDHPInterfaceObjects2= [];
gdjs.lvl5Code.GDHPInterfaceObjects3= [];
gdjs.lvl5Code.GDScoreInterfaceObjects1= [];
gdjs.lvl5Code.GDScoreInterfaceObjects2= [];
gdjs.lvl5Code.GDScoreInterfaceObjects3= [];
gdjs.lvl5Code.GDKeyInterfaceObjects1= [];
gdjs.lvl5Code.GDKeyInterfaceObjects2= [];
gdjs.lvl5Code.GDKeyInterfaceObjects3= [];
gdjs.lvl5Code.GDHPTextObjects1= [];
gdjs.lvl5Code.GDHPTextObjects2= [];
gdjs.lvl5Code.GDHPTextObjects3= [];
gdjs.lvl5Code.GDScoreTextObjects1= [];
gdjs.lvl5Code.GDScoreTextObjects2= [];
gdjs.lvl5Code.GDScoreTextObjects3= [];
gdjs.lvl5Code.GDDoorObjects1= [];
gdjs.lvl5Code.GDDoorObjects2= [];
gdjs.lvl5Code.GDDoorObjects3= [];
gdjs.lvl5Code.GDKey2Objects1= [];
gdjs.lvl5Code.GDKey2Objects2= [];
gdjs.lvl5Code.GDKey2Objects3= [];
gdjs.lvl5Code.GDSpawnPointObjects1= [];
gdjs.lvl5Code.GDSpawnPointObjects2= [];
gdjs.lvl5Code.GDSpawnPointObjects3= [];
gdjs.lvl5Code.GDStartLvl1Objects1= [];
gdjs.lvl5Code.GDStartLvl1Objects2= [];
gdjs.lvl5Code.GDStartLvl1Objects3= [];
gdjs.lvl5Code.GDStartLvl2Objects1= [];
gdjs.lvl5Code.GDStartLvl2Objects2= [];
gdjs.lvl5Code.GDStartLvl2Objects3= [];
gdjs.lvl5Code.GDStartLvl3Objects1= [];
gdjs.lvl5Code.GDStartLvl3Objects2= [];
gdjs.lvl5Code.GDStartLvl3Objects3= [];
gdjs.lvl5Code.GD_9595_9595_9595Objects1= [];
gdjs.lvl5Code.GD_9595_9595_9595Objects2= [];
gdjs.lvl5Code.GD_9595_9595_9595Objects3= [];
gdjs.lvl5Code.GD_9595_9595_95952Objects1= [];
gdjs.lvl5Code.GD_9595_9595_95952Objects2= [];
gdjs.lvl5Code.GD_9595_9595_95952Objects3= [];


gdjs.lvl5Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].setAnimationFrame(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].setAnimationFrame(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects1.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects1[k] = gdjs.lvl5Code.GDPlayerSpriteObjects1[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDPlayerSpriteObjects1 */
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects1.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


};gdjs.lvl5Code.asyncCallback11520612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl5Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects3);

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.lvl5Code.GDSpawnPointObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.lvl5Code.GDPlayerSpriteObjects3.length ;i < len;++i) {
    gdjs.lvl5Code.GDPlayerSpriteObjects3[i].setPosition((( gdjs.lvl5Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl5Code.GDSpawnPointObjects3[0].getPointX("")),(( gdjs.lvl5Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl5Code.GDSpawnPointObjects3[0].getPointY("")));
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-mechanical-crate-pick-up-3154.wav", false, 100, 1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-casino-bling-achievement-2067.wav", false, 100, 1);
}
gdjs.lvl5Code.localVariables.length = 0;
}
gdjs.lvl5Code.idToCallbackMap.set(11520612, gdjs.lvl5Code.asyncCallback11520612);
gdjs.lvl5Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl5Code.localVariables);
for (const obj of gdjs.lvl5Code.GDPlayerSpriteObjects2) asyncObjectsList.addObject("PlayerSprite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.lvl5Code.asyncCallback11520612(runtimeScene, asyncObjectsList)), 11520612, asyncObjectsList);
}
}

}


};gdjs.lvl5Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11520068);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl5Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.lvl5Code.asyncCallback11522684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl5Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}
gdjs.lvl5Code.localVariables.length = 0;
}
gdjs.lvl5Code.idToCallbackMap.set(11522684, gdjs.lvl5Code.asyncCallback11522684);
gdjs.lvl5Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl5Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.lvl5Code.asyncCallback11522684(runtimeScene, asyncObjectsList)), 11522684, asyncObjectsList);
}
}

}


};gdjs.lvl5Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDPlayerSpriteObjects2[i].getY() > 355 ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDPlayerSpriteObjects2[k] = gdjs.lvl5Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl5Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-player-losing-or-failing-2042.wav", false, 100, 1);
}

{ //Subevents
gdjs.lvl5Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl5Code.GDPlayerSpriteObjects2});
gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDScoreInterfaceObjects2Objects = Hashtable.newFrom({"ScoreInterface": gdjs.lvl5Code.GDScoreInterfaceObjects2});
gdjs.lvl5Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreInterface"), gdjs.lvl5Code.GDScoreInterfaceObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDScoreInterfaceObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDScoreInterfaceObjects2 */
{for(var i = 0, len = gdjs.lvl5Code.GDScoreInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDScoreInterfaceObjects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-winning-a-coin-video-game-2069.wav", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-video-game-health-recharge-2837.wav", false, 100, 1);
}
}

}


};gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl5Code.GDPlayerSpriteObjects2});
gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDKey2Objects2Objects = Hashtable.newFrom({"Key2": gdjs.lvl5Code.GDKey2Objects2});
gdjs.lvl5Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11528692);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(true);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 100, 1);
}
}

}


};gdjs.lvl5Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl5Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDKey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl5Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl5Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl5Code.GDKeyInterfaceObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);
{for(var i = 0, len = gdjs.lvl5Code.GDKey2Objects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDKey2Objects2[i].setPosition((( gdjs.lvl5Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl5Code.GDPlayerSpriteObjects2[0].getCenterXInScene()) - 8,(( gdjs.lvl5Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl5Code.GDPlayerSpriteObjects2[0].getCenterYInScene()) - 4);
}
}
{for(var i = 0, len = gdjs.lvl5Code.GDKeyInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl5Code.GDKeyInterfaceObjects2[i].setColor("255;255;255");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11530828);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl5Code.GDKeyInterfaceObjects1);
{for(var i = 0, len = gdjs.lvl5Code.GDKeyInterfaceObjects1.length ;i < len;++i) {
    gdjs.lvl5Code.GDKeyInterfaceObjects1[i].setColor("35;35;46");
}
}
}

}


};gdjs.lvl5Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.lvl5Code.GDPlayerSpriteObjects2.length !== 0 ? gdjs.lvl5Code.GDPlayerSpriteObjects2[0] : null), true, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, -476, 80, 1434, 355, "", 0);
}
}

}


};gdjs.lvl5Code.asyncCallback11417564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl5Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "???", false);
}
gdjs.lvl5Code.localVariables.length = 0;
}
gdjs.lvl5Code.idToCallbackMap.set(11417564, gdjs.lvl5Code.asyncCallback11417564);
gdjs.lvl5Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl5Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.lvl5Code.asyncCallback11417564(runtimeScene, asyncObjectsList)), 11417564, asyncObjectsList);
}
}

}


};gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects1Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl5Code.GDPlayerSpriteObjects1});
gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.lvl5Code.GDDoorObjects1});
gdjs.lvl5Code.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.lvl5Code.GDDoorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl5Code.GDDoorObjects1.length;i<l;++i) {
    if ( gdjs.lvl5Code.GDDoorObjects1[i].getBehavior("Animation").getAnimationName() == "Opened" ) {
        isConditionTrue_0 = true;
        gdjs.lvl5Code.GDDoorObjects1[k] = gdjs.lvl5Code.GDDoorObjects1[i];
        ++k;
    }
}
gdjs.lvl5Code.GDDoorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Win", false);
}
}

}


};gdjs.lvl5Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}
}

}


{


gdjs.lvl5Code.eventsList0(runtimeScene);
}


{


gdjs.lvl5Code.eventsList4(runtimeScene);
}


{


gdjs.lvl5Code.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HPText"), gdjs.lvl5Code.GDHPTextObjects1);
{for(var i = 0, len = gdjs.lvl5Code.GDHPTextObjects1.length ;i < len;++i) {
    gdjs.lvl5Code.GDHPTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.lvl5Code.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.lvl5Code.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.lvl5Code.GDScoreTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


gdjs.lvl5Code.eventsList7(runtimeScene);
}


{


gdjs.lvl5Code.eventsList8(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-player-losing-or-failing-2042.wav", false, 100, 1);
}

{ //Subevents
gdjs.lvl5Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11418204);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UserInterface", 0, 0, 0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "freesound_community-radio-frequency-interference-26901.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.lvl5Code.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl5Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDPlayerSpriteObjects1Objects, gdjs.lvl5Code.mapOfGDgdjs_9546lvl5Code_9546GDDoorObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl5Code.GDDoorObjects1 */
{for(var i = 0, len = gdjs.lvl5Code.GDDoorObjects1.length ;i < len;++i) {
    gdjs.lvl5Code.GDDoorObjects1[i].getBehavior("Animation").setAnimationName("Opened");
}
}

{ //Subevents
gdjs.lvl5Code.eventsList10(runtimeScene);} //End of subevents
}

}


};

gdjs.lvl5Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl5Code.GDNewTextObjects1.length = 0;
gdjs.lvl5Code.GDNewTextObjects2.length = 0;
gdjs.lvl5Code.GDNewTextObjects3.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDHPTextObjects1.length = 0;
gdjs.lvl5Code.GDHPTextObjects2.length = 0;
gdjs.lvl5Code.GDHPTextObjects3.length = 0;
gdjs.lvl5Code.GDScoreTextObjects1.length = 0;
gdjs.lvl5Code.GDScoreTextObjects2.length = 0;
gdjs.lvl5Code.GDScoreTextObjects3.length = 0;
gdjs.lvl5Code.GDDoorObjects1.length = 0;
gdjs.lvl5Code.GDDoorObjects2.length = 0;
gdjs.lvl5Code.GDDoorObjects3.length = 0;
gdjs.lvl5Code.GDKey2Objects1.length = 0;
gdjs.lvl5Code.GDKey2Objects2.length = 0;
gdjs.lvl5Code.GDKey2Objects3.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects3.length = 0;

gdjs.lvl5Code.eventsList11(runtimeScene);
gdjs.lvl5Code.GDNewTextObjects1.length = 0;
gdjs.lvl5Code.GDNewTextObjects2.length = 0;
gdjs.lvl5Code.GDNewTextObjects3.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl5Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl5Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl5Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl5Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl5Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl5Code.GDHPTextObjects1.length = 0;
gdjs.lvl5Code.GDHPTextObjects2.length = 0;
gdjs.lvl5Code.GDHPTextObjects3.length = 0;
gdjs.lvl5Code.GDScoreTextObjects1.length = 0;
gdjs.lvl5Code.GDScoreTextObjects2.length = 0;
gdjs.lvl5Code.GDScoreTextObjects3.length = 0;
gdjs.lvl5Code.GDDoorObjects1.length = 0;
gdjs.lvl5Code.GDDoorObjects2.length = 0;
gdjs.lvl5Code.GDDoorObjects3.length = 0;
gdjs.lvl5Code.GDKey2Objects1.length = 0;
gdjs.lvl5Code.GDKey2Objects2.length = 0;
gdjs.lvl5Code.GDKey2Objects3.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl5Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl5Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl5Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl5Code.GD_9595_9595_95952Objects3.length = 0;


return;

}

gdjs['lvl5Code'] = gdjs.lvl5Code;
