gdjs._63_63_63Code = {};
gdjs._63_63_63Code.localVariables = [];
gdjs._63_63_63Code.idToCallbackMap = new Map();
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1= [];
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects2= [];
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects3= [];
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects4= [];
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects5= [];
gdjs._63_63_63Code.GDNewTextObjects1= [];
gdjs._63_63_63Code.GDNewTextObjects2= [];
gdjs._63_63_63Code.GDNewTextObjects3= [];
gdjs._63_63_63Code.GDNewTextObjects4= [];
gdjs._63_63_63Code.GDNewTextObjects5= [];
gdjs._63_63_63Code.GDNewText2Objects1= [];
gdjs._63_63_63Code.GDNewText2Objects2= [];
gdjs._63_63_63Code.GDNewText2Objects3= [];
gdjs._63_63_63Code.GDNewText2Objects4= [];
gdjs._63_63_63Code.GDNewText2Objects5= [];
gdjs._63_63_63Code.GDNewText3Objects1= [];
gdjs._63_63_63Code.GDNewText3Objects2= [];
gdjs._63_63_63Code.GDNewText3Objects3= [];
gdjs._63_63_63Code.GDNewText3Objects4= [];
gdjs._63_63_63Code.GDNewText3Objects5= [];
gdjs._63_63_63Code.GDNewText4Objects1= [];
gdjs._63_63_63Code.GDNewText4Objects2= [];
gdjs._63_63_63Code.GDNewText4Objects3= [];
gdjs._63_63_63Code.GDNewText4Objects4= [];
gdjs._63_63_63Code.GDNewText4Objects5= [];
gdjs._63_63_63Code.GDPlayerSpriteObjects1= [];
gdjs._63_63_63Code.GDPlayerSpriteObjects2= [];
gdjs._63_63_63Code.GDPlayerSpriteObjects3= [];
gdjs._63_63_63Code.GDPlayerSpriteObjects4= [];
gdjs._63_63_63Code.GDPlayerSpriteObjects5= [];
gdjs._63_63_63Code.GDNewSpriteObjects1= [];
gdjs._63_63_63Code.GDNewSpriteObjects2= [];
gdjs._63_63_63Code.GDNewSpriteObjects3= [];
gdjs._63_63_63Code.GDNewSpriteObjects4= [];
gdjs._63_63_63Code.GDNewSpriteObjects5= [];
gdjs._63_63_63Code.GDCollisionBlockObjects1= [];
gdjs._63_63_63Code.GDCollisionBlockObjects2= [];
gdjs._63_63_63Code.GDCollisionBlockObjects3= [];
gdjs._63_63_63Code.GDCollisionBlockObjects4= [];
gdjs._63_63_63Code.GDCollisionBlockObjects5= [];
gdjs._63_63_63Code.GDNewTileMapObjects1= [];
gdjs._63_63_63Code.GDNewTileMapObjects2= [];
gdjs._63_63_63Code.GDNewTileMapObjects3= [];
gdjs._63_63_63Code.GDNewTileMapObjects4= [];
gdjs._63_63_63Code.GDNewTileMapObjects5= [];
gdjs._63_63_63Code.GDFrameInterfaceObjects1= [];
gdjs._63_63_63Code.GDFrameInterfaceObjects2= [];
gdjs._63_63_63Code.GDFrameInterfaceObjects3= [];
gdjs._63_63_63Code.GDFrameInterfaceObjects4= [];
gdjs._63_63_63Code.GDFrameInterfaceObjects5= [];
gdjs._63_63_63Code.GDHPInterfaceObjects1= [];
gdjs._63_63_63Code.GDHPInterfaceObjects2= [];
gdjs._63_63_63Code.GDHPInterfaceObjects3= [];
gdjs._63_63_63Code.GDHPInterfaceObjects4= [];
gdjs._63_63_63Code.GDHPInterfaceObjects5= [];
gdjs._63_63_63Code.GDScoreInterfaceObjects1= [];
gdjs._63_63_63Code.GDScoreInterfaceObjects2= [];
gdjs._63_63_63Code.GDScoreInterfaceObjects3= [];
gdjs._63_63_63Code.GDScoreInterfaceObjects4= [];
gdjs._63_63_63Code.GDScoreInterfaceObjects5= [];
gdjs._63_63_63Code.GDKeyInterfaceObjects1= [];
gdjs._63_63_63Code.GDKeyInterfaceObjects2= [];
gdjs._63_63_63Code.GDKeyInterfaceObjects3= [];
gdjs._63_63_63Code.GDKeyInterfaceObjects4= [];
gdjs._63_63_63Code.GDKeyInterfaceObjects5= [];
gdjs._63_63_63Code.GDHPTextObjects1= [];
gdjs._63_63_63Code.GDHPTextObjects2= [];
gdjs._63_63_63Code.GDHPTextObjects3= [];
gdjs._63_63_63Code.GDHPTextObjects4= [];
gdjs._63_63_63Code.GDHPTextObjects5= [];
gdjs._63_63_63Code.GDScoreTextObjects1= [];
gdjs._63_63_63Code.GDScoreTextObjects2= [];
gdjs._63_63_63Code.GDScoreTextObjects3= [];
gdjs._63_63_63Code.GDScoreTextObjects4= [];
gdjs._63_63_63Code.GDScoreTextObjects5= [];
gdjs._63_63_63Code.GDDoorObjects1= [];
gdjs._63_63_63Code.GDDoorObjects2= [];
gdjs._63_63_63Code.GDDoorObjects3= [];
gdjs._63_63_63Code.GDDoorObjects4= [];
gdjs._63_63_63Code.GDDoorObjects5= [];
gdjs._63_63_63Code.GDKey2Objects1= [];
gdjs._63_63_63Code.GDKey2Objects2= [];
gdjs._63_63_63Code.GDKey2Objects3= [];
gdjs._63_63_63Code.GDKey2Objects4= [];
gdjs._63_63_63Code.GDKey2Objects5= [];
gdjs._63_63_63Code.GDSpawnPointObjects1= [];
gdjs._63_63_63Code.GDSpawnPointObjects2= [];
gdjs._63_63_63Code.GDSpawnPointObjects3= [];
gdjs._63_63_63Code.GDSpawnPointObjects4= [];
gdjs._63_63_63Code.GDSpawnPointObjects5= [];
gdjs._63_63_63Code.GDStartLvl1Objects1= [];
gdjs._63_63_63Code.GDStartLvl1Objects2= [];
gdjs._63_63_63Code.GDStartLvl1Objects3= [];
gdjs._63_63_63Code.GDStartLvl1Objects4= [];
gdjs._63_63_63Code.GDStartLvl1Objects5= [];
gdjs._63_63_63Code.GDStartLvl2Objects1= [];
gdjs._63_63_63Code.GDStartLvl2Objects2= [];
gdjs._63_63_63Code.GDStartLvl2Objects3= [];
gdjs._63_63_63Code.GDStartLvl2Objects4= [];
gdjs._63_63_63Code.GDStartLvl2Objects5= [];
gdjs._63_63_63Code.GDStartLvl3Objects1= [];
gdjs._63_63_63Code.GDStartLvl3Objects2= [];
gdjs._63_63_63Code.GDStartLvl3Objects3= [];
gdjs._63_63_63Code.GDStartLvl3Objects4= [];
gdjs._63_63_63Code.GDStartLvl3Objects5= [];
gdjs._63_63_63Code.GD_9595_9595_9595Objects1= [];
gdjs._63_63_63Code.GD_9595_9595_9595Objects2= [];
gdjs._63_63_63Code.GD_9595_9595_9595Objects3= [];
gdjs._63_63_63Code.GD_9595_9595_9595Objects4= [];
gdjs._63_63_63Code.GD_9595_9595_9595Objects5= [];
gdjs._63_63_63Code.GD_9595_9595_95952Objects1= [];
gdjs._63_63_63Code.GD_9595_9595_95952Objects2= [];
gdjs._63_63_63Code.GD_9595_9595_95952Objects3= [];
gdjs._63_63_63Code.GD_9595_9595_95952Objects4= [];
gdjs._63_63_63Code.GD_9595_9595_95952Objects5= [];


gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewTextObjects1Objects = Hashtable.newFrom({"NewText": gdjs._63_63_63Code.GDNewTextObjects1});
gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText2Objects2Objects = Hashtable.newFrom({"NewText2": gdjs._63_63_63Code.GDNewText2Objects2});
gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText3Objects3Objects = Hashtable.newFrom({"NewText3": gdjs._63_63_63Code.GDNewText3Objects3});
gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText4Objects4Objects = Hashtable.newFrom({"NewText4": gdjs._63_63_63Code.GDNewText4Objects4});
gdjs._63_63_63Code.asyncCallback11479396 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "InitialMenu", false);
}
gdjs._63_63_63Code.localVariables.length = 0;
}
gdjs._63_63_63Code.idToCallbackMap.set(11479396, gdjs._63_63_63Code.asyncCallback11479396);
gdjs._63_63_63Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2.5), (runtimeScene) => (gdjs._63_63_63Code.asyncCallback11479396(runtimeScene, asyncObjectsList)), 11479396, asyncObjectsList);
}
}

}


};gdjs._63_63_63Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs._63_63_63Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs._63_63_63Code.asyncCallback11478332 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewText3"), gdjs._63_63_63Code.GDNewText3Objects4);

gdjs._63_63_63Code.GDNewText4Objects4.length = 0;

{for(var i = 0, len = gdjs._63_63_63Code.GDNewText3Objects4.length ;i < len;++i) {
    gdjs._63_63_63Code.GDNewText3Objects4[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText4Objects4Objects, 70, 224, "");
}

{ //Subevents
gdjs._63_63_63Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs._63_63_63Code.localVariables.length = 0;
}
gdjs._63_63_63Code.idToCallbackMap.set(11478332, gdjs._63_63_63Code.asyncCallback11478332);
gdjs._63_63_63Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
for (const obj of gdjs._63_63_63Code.GDNewText3Objects3) asyncObjectsList.addObject("NewText3", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2.5), (runtimeScene) => (gdjs._63_63_63Code.asyncCallback11478332(runtimeScene, asyncObjectsList)), 11478332, asyncObjectsList);
}
}

}


};gdjs._63_63_63Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs._63_63_63Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs._63_63_63Code.asyncCallback11474796 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewText2"), gdjs._63_63_63Code.GDNewText2Objects3);

gdjs._63_63_63Code.GDNewText3Objects3.length = 0;

{for(var i = 0, len = gdjs._63_63_63Code.GDNewText2Objects3.length ;i < len;++i) {
    gdjs._63_63_63Code.GDNewText2Objects3[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText3Objects3Objects, 100, 224, "");
}

{ //Subevents
gdjs._63_63_63Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
gdjs._63_63_63Code.localVariables.length = 0;
}
gdjs._63_63_63Code.idToCallbackMap.set(11474796, gdjs._63_63_63Code.asyncCallback11474796);
gdjs._63_63_63Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
for (const obj of gdjs._63_63_63Code.GDNewText2Objects2) asyncObjectsList.addObject("NewText2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2.5), (runtimeScene) => (gdjs._63_63_63Code.asyncCallback11474796(runtimeScene, asyncObjectsList)), 11474796, asyncObjectsList);
}
}

}


};gdjs._63_63_63Code.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs._63_63_63Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs._63_63_63Code.asyncCallback11474020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewText"), gdjs._63_63_63Code.GDNewTextObjects2);

gdjs._63_63_63Code.GDNewText2Objects2.length = 0;

{for(var i = 0, len = gdjs._63_63_63Code.GDNewTextObjects2.length ;i < len;++i) {
    gdjs._63_63_63Code.GDNewTextObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewText2Objects2Objects, 123, 224, "");
}

{ //Subevents
gdjs._63_63_63Code.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
gdjs._63_63_63Code.localVariables.length = 0;
}
gdjs._63_63_63Code.idToCallbackMap.set(11474020, gdjs._63_63_63Code.asyncCallback11474020);
gdjs._63_63_63Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs._63_63_63Code.localVariables);
for (const obj of gdjs._63_63_63Code.GDNewTextObjects1) asyncObjectsList.addObject("NewText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2.5), (runtimeScene) => (gdjs._63_63_63Code.asyncCallback11474020(runtimeScene, asyncObjectsList)), 11474020, asyncObjectsList);
}
}

}


};gdjs._63_63_63Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("frame___"), gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1);
{for(var i = 0, len = gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1.length ;i < len;++i) {
    gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("frame___"), gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1);
gdjs._63_63_63Code.GDNewTextObjects1.length = 0;

{for(var i = 0, len = gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1.length ;i < len;++i) {
    gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1[i].hide(false);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs._63_63_63Code.mapOfGDgdjs_9546_959563_959563_959563Code_9546GDNewTextObjects1Objects, 227, 224, "");
}

{ //Subevents
gdjs._63_63_63Code.eventsList6(runtimeScene);} //End of subevents
}

}


};

gdjs._63_63_63Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects2.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects3.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects4.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects5.length = 0;
gdjs._63_63_63Code.GDNewTextObjects1.length = 0;
gdjs._63_63_63Code.GDNewTextObjects2.length = 0;
gdjs._63_63_63Code.GDNewTextObjects3.length = 0;
gdjs._63_63_63Code.GDNewTextObjects4.length = 0;
gdjs._63_63_63Code.GDNewTextObjects5.length = 0;
gdjs._63_63_63Code.GDNewText2Objects1.length = 0;
gdjs._63_63_63Code.GDNewText2Objects2.length = 0;
gdjs._63_63_63Code.GDNewText2Objects3.length = 0;
gdjs._63_63_63Code.GDNewText2Objects4.length = 0;
gdjs._63_63_63Code.GDNewText2Objects5.length = 0;
gdjs._63_63_63Code.GDNewText3Objects1.length = 0;
gdjs._63_63_63Code.GDNewText3Objects2.length = 0;
gdjs._63_63_63Code.GDNewText3Objects3.length = 0;
gdjs._63_63_63Code.GDNewText3Objects4.length = 0;
gdjs._63_63_63Code.GDNewText3Objects5.length = 0;
gdjs._63_63_63Code.GDNewText4Objects1.length = 0;
gdjs._63_63_63Code.GDNewText4Objects2.length = 0;
gdjs._63_63_63Code.GDNewText4Objects3.length = 0;
gdjs._63_63_63Code.GDNewText4Objects4.length = 0;
gdjs._63_63_63Code.GDNewText4Objects5.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects1.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects2.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects3.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects4.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects5.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects1.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects2.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects3.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects4.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects5.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects1.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects2.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects3.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects4.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects5.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects1.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects2.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects3.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects4.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects5.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDHPTextObjects1.length = 0;
gdjs._63_63_63Code.GDHPTextObjects2.length = 0;
gdjs._63_63_63Code.GDHPTextObjects3.length = 0;
gdjs._63_63_63Code.GDHPTextObjects4.length = 0;
gdjs._63_63_63Code.GDHPTextObjects5.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects1.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects2.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects3.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects4.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects5.length = 0;
gdjs._63_63_63Code.GDDoorObjects1.length = 0;
gdjs._63_63_63Code.GDDoorObjects2.length = 0;
gdjs._63_63_63Code.GDDoorObjects3.length = 0;
gdjs._63_63_63Code.GDDoorObjects4.length = 0;
gdjs._63_63_63Code.GDDoorObjects5.length = 0;
gdjs._63_63_63Code.GDKey2Objects1.length = 0;
gdjs._63_63_63Code.GDKey2Objects2.length = 0;
gdjs._63_63_63Code.GDKey2Objects3.length = 0;
gdjs._63_63_63Code.GDKey2Objects4.length = 0;
gdjs._63_63_63Code.GDKey2Objects5.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects1.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects2.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects3.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects4.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects5.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects5.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects5.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects5.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects1.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects2.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects3.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects4.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects5.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects1.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects2.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects3.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects4.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects5.length = 0;

gdjs._63_63_63Code.eventsList7(runtimeScene);
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects1.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects2.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects3.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects4.length = 0;
gdjs._63_63_63Code.GDframe_9595_9595_9595Objects5.length = 0;
gdjs._63_63_63Code.GDNewTextObjects1.length = 0;
gdjs._63_63_63Code.GDNewTextObjects2.length = 0;
gdjs._63_63_63Code.GDNewTextObjects3.length = 0;
gdjs._63_63_63Code.GDNewTextObjects4.length = 0;
gdjs._63_63_63Code.GDNewTextObjects5.length = 0;
gdjs._63_63_63Code.GDNewText2Objects1.length = 0;
gdjs._63_63_63Code.GDNewText2Objects2.length = 0;
gdjs._63_63_63Code.GDNewText2Objects3.length = 0;
gdjs._63_63_63Code.GDNewText2Objects4.length = 0;
gdjs._63_63_63Code.GDNewText2Objects5.length = 0;
gdjs._63_63_63Code.GDNewText3Objects1.length = 0;
gdjs._63_63_63Code.GDNewText3Objects2.length = 0;
gdjs._63_63_63Code.GDNewText3Objects3.length = 0;
gdjs._63_63_63Code.GDNewText3Objects4.length = 0;
gdjs._63_63_63Code.GDNewText3Objects5.length = 0;
gdjs._63_63_63Code.GDNewText4Objects1.length = 0;
gdjs._63_63_63Code.GDNewText4Objects2.length = 0;
gdjs._63_63_63Code.GDNewText4Objects3.length = 0;
gdjs._63_63_63Code.GDNewText4Objects4.length = 0;
gdjs._63_63_63Code.GDNewText4Objects5.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects1.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects2.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects3.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects4.length = 0;
gdjs._63_63_63Code.GDPlayerSpriteObjects5.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects1.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects2.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects3.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects4.length = 0;
gdjs._63_63_63Code.GDNewSpriteObjects5.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects1.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects2.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects3.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects4.length = 0;
gdjs._63_63_63Code.GDCollisionBlockObjects5.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects1.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects2.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects3.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects4.length = 0;
gdjs._63_63_63Code.GDNewTileMapObjects5.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDFrameInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDHPInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDScoreInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects1.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects2.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects3.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects4.length = 0;
gdjs._63_63_63Code.GDKeyInterfaceObjects5.length = 0;
gdjs._63_63_63Code.GDHPTextObjects1.length = 0;
gdjs._63_63_63Code.GDHPTextObjects2.length = 0;
gdjs._63_63_63Code.GDHPTextObjects3.length = 0;
gdjs._63_63_63Code.GDHPTextObjects4.length = 0;
gdjs._63_63_63Code.GDHPTextObjects5.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects1.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects2.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects3.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects4.length = 0;
gdjs._63_63_63Code.GDScoreTextObjects5.length = 0;
gdjs._63_63_63Code.GDDoorObjects1.length = 0;
gdjs._63_63_63Code.GDDoorObjects2.length = 0;
gdjs._63_63_63Code.GDDoorObjects3.length = 0;
gdjs._63_63_63Code.GDDoorObjects4.length = 0;
gdjs._63_63_63Code.GDDoorObjects5.length = 0;
gdjs._63_63_63Code.GDKey2Objects1.length = 0;
gdjs._63_63_63Code.GDKey2Objects2.length = 0;
gdjs._63_63_63Code.GDKey2Objects3.length = 0;
gdjs._63_63_63Code.GDKey2Objects4.length = 0;
gdjs._63_63_63Code.GDKey2Objects5.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects1.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects2.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects3.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects4.length = 0;
gdjs._63_63_63Code.GDSpawnPointObjects5.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl1Objects5.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl2Objects5.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects1.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects2.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects3.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects4.length = 0;
gdjs._63_63_63Code.GDStartLvl3Objects5.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects1.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects2.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects3.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects4.length = 0;
gdjs._63_63_63Code.GD_9595_9595_9595Objects5.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects1.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects2.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects3.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects4.length = 0;
gdjs._63_63_63Code.GD_9595_9595_95952Objects5.length = 0;


return;

}

gdjs['_63_63_63Code'] = gdjs._63_63_63Code;
