gdjs.WinCode = {};
gdjs.WinCode.localVariables = [];
gdjs.WinCode.idToCallbackMap = new Map();
gdjs.WinCode.GDNewTextObjects1= [];
gdjs.WinCode.GDNewTextObjects2= [];
gdjs.WinCode.GDPlayerSpriteObjects1= [];
gdjs.WinCode.GDPlayerSpriteObjects2= [];
gdjs.WinCode.GDNewSpriteObjects1= [];
gdjs.WinCode.GDNewSpriteObjects2= [];
gdjs.WinCode.GDCollisionBlockObjects1= [];
gdjs.WinCode.GDCollisionBlockObjects2= [];
gdjs.WinCode.GDNewTileMapObjects1= [];
gdjs.WinCode.GDNewTileMapObjects2= [];
gdjs.WinCode.GDFrameInterfaceObjects1= [];
gdjs.WinCode.GDFrameInterfaceObjects2= [];
gdjs.WinCode.GDHPInterfaceObjects1= [];
gdjs.WinCode.GDHPInterfaceObjects2= [];
gdjs.WinCode.GDScoreInterfaceObjects1= [];
gdjs.WinCode.GDScoreInterfaceObjects2= [];
gdjs.WinCode.GDKeyInterfaceObjects1= [];
gdjs.WinCode.GDKeyInterfaceObjects2= [];
gdjs.WinCode.GDHPTextObjects1= [];
gdjs.WinCode.GDHPTextObjects2= [];
gdjs.WinCode.GDScoreTextObjects1= [];
gdjs.WinCode.GDScoreTextObjects2= [];
gdjs.WinCode.GDDoorObjects1= [];
gdjs.WinCode.GDDoorObjects2= [];
gdjs.WinCode.GDKey2Objects1= [];
gdjs.WinCode.GDKey2Objects2= [];
gdjs.WinCode.GDSpawnPointObjects1= [];
gdjs.WinCode.GDSpawnPointObjects2= [];
gdjs.WinCode.GDStartLvl1Objects1= [];
gdjs.WinCode.GDStartLvl1Objects2= [];
gdjs.WinCode.GDStartLvl2Objects1= [];
gdjs.WinCode.GDStartLvl2Objects2= [];
gdjs.WinCode.GDStartLvl3Objects1= [];
gdjs.WinCode.GDStartLvl3Objects2= [];
gdjs.WinCode.GD_9595_9595_9595Objects1= [];
gdjs.WinCode.GD_9595_9595_9595Objects2= [];
gdjs.WinCode.GD_9595_9595_95952Objects1= [];
gdjs.WinCode.GD_9595_9595_95952Objects2= [];


gdjs.WinCode.asyncCallback11500204 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.WinCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "InitialMenu", false);
}
gdjs.WinCode.localVariables.length = 0;
}
gdjs.WinCode.idToCallbackMap.set(11500204, gdjs.WinCode.asyncCallback11500204);
gdjs.WinCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.WinCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5.5), (runtimeScene) => (gdjs.WinCode.asyncCallback11500204(runtimeScene, asyncObjectsList)), 11500204, asyncObjectsList);
}
}

}


};gdjs.WinCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.WinCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.WinCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mrstokes302-success-videogame-sfx-mrstokes302-423626.mp3", false, 100, 1.7);
}

{ //Subevents
gdjs.WinCode.eventsList1(runtimeScene);} //End of subevents
}

}


};

gdjs.WinCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.WinCode.GDNewTextObjects1.length = 0;
gdjs.WinCode.GDNewTextObjects2.length = 0;
gdjs.WinCode.GDPlayerSpriteObjects1.length = 0;
gdjs.WinCode.GDPlayerSpriteObjects2.length = 0;
gdjs.WinCode.GDNewSpriteObjects1.length = 0;
gdjs.WinCode.GDNewSpriteObjects2.length = 0;
gdjs.WinCode.GDCollisionBlockObjects1.length = 0;
gdjs.WinCode.GDCollisionBlockObjects2.length = 0;
gdjs.WinCode.GDNewTileMapObjects1.length = 0;
gdjs.WinCode.GDNewTileMapObjects2.length = 0;
gdjs.WinCode.GDFrameInterfaceObjects1.length = 0;
gdjs.WinCode.GDFrameInterfaceObjects2.length = 0;
gdjs.WinCode.GDHPInterfaceObjects1.length = 0;
gdjs.WinCode.GDHPInterfaceObjects2.length = 0;
gdjs.WinCode.GDScoreInterfaceObjects1.length = 0;
gdjs.WinCode.GDScoreInterfaceObjects2.length = 0;
gdjs.WinCode.GDKeyInterfaceObjects1.length = 0;
gdjs.WinCode.GDKeyInterfaceObjects2.length = 0;
gdjs.WinCode.GDHPTextObjects1.length = 0;
gdjs.WinCode.GDHPTextObjects2.length = 0;
gdjs.WinCode.GDScoreTextObjects1.length = 0;
gdjs.WinCode.GDScoreTextObjects2.length = 0;
gdjs.WinCode.GDDoorObjects1.length = 0;
gdjs.WinCode.GDDoorObjects2.length = 0;
gdjs.WinCode.GDKey2Objects1.length = 0;
gdjs.WinCode.GDKey2Objects2.length = 0;
gdjs.WinCode.GDSpawnPointObjects1.length = 0;
gdjs.WinCode.GDSpawnPointObjects2.length = 0;
gdjs.WinCode.GDStartLvl1Objects1.length = 0;
gdjs.WinCode.GDStartLvl1Objects2.length = 0;
gdjs.WinCode.GDStartLvl2Objects1.length = 0;
gdjs.WinCode.GDStartLvl2Objects2.length = 0;
gdjs.WinCode.GDStartLvl3Objects1.length = 0;
gdjs.WinCode.GDStartLvl3Objects2.length = 0;
gdjs.WinCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.WinCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.WinCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.WinCode.GD_9595_9595_95952Objects2.length = 0;

gdjs.WinCode.eventsList2(runtimeScene);
gdjs.WinCode.GDNewTextObjects1.length = 0;
gdjs.WinCode.GDNewTextObjects2.length = 0;
gdjs.WinCode.GDPlayerSpriteObjects1.length = 0;
gdjs.WinCode.GDPlayerSpriteObjects2.length = 0;
gdjs.WinCode.GDNewSpriteObjects1.length = 0;
gdjs.WinCode.GDNewSpriteObjects2.length = 0;
gdjs.WinCode.GDCollisionBlockObjects1.length = 0;
gdjs.WinCode.GDCollisionBlockObjects2.length = 0;
gdjs.WinCode.GDNewTileMapObjects1.length = 0;
gdjs.WinCode.GDNewTileMapObjects2.length = 0;
gdjs.WinCode.GDFrameInterfaceObjects1.length = 0;
gdjs.WinCode.GDFrameInterfaceObjects2.length = 0;
gdjs.WinCode.GDHPInterfaceObjects1.length = 0;
gdjs.WinCode.GDHPInterfaceObjects2.length = 0;
gdjs.WinCode.GDScoreInterfaceObjects1.length = 0;
gdjs.WinCode.GDScoreInterfaceObjects2.length = 0;
gdjs.WinCode.GDKeyInterfaceObjects1.length = 0;
gdjs.WinCode.GDKeyInterfaceObjects2.length = 0;
gdjs.WinCode.GDHPTextObjects1.length = 0;
gdjs.WinCode.GDHPTextObjects2.length = 0;
gdjs.WinCode.GDScoreTextObjects1.length = 0;
gdjs.WinCode.GDScoreTextObjects2.length = 0;
gdjs.WinCode.GDDoorObjects1.length = 0;
gdjs.WinCode.GDDoorObjects2.length = 0;
gdjs.WinCode.GDKey2Objects1.length = 0;
gdjs.WinCode.GDKey2Objects2.length = 0;
gdjs.WinCode.GDSpawnPointObjects1.length = 0;
gdjs.WinCode.GDSpawnPointObjects2.length = 0;
gdjs.WinCode.GDStartLvl1Objects1.length = 0;
gdjs.WinCode.GDStartLvl1Objects2.length = 0;
gdjs.WinCode.GDStartLvl2Objects1.length = 0;
gdjs.WinCode.GDStartLvl2Objects2.length = 0;
gdjs.WinCode.GDStartLvl3Objects1.length = 0;
gdjs.WinCode.GDStartLvl3Objects2.length = 0;
gdjs.WinCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.WinCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.WinCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.WinCode.GD_9595_9595_95952Objects2.length = 0;


return;

}

gdjs['WinCode'] = gdjs.WinCode;
