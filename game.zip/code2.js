gdjs.lvl2Code = {};
gdjs.lvl2Code.localVariables = [];
gdjs.lvl2Code.idToCallbackMap = new Map();
gdjs.lvl2Code.GDPlayerSpriteObjects1= [];
gdjs.lvl2Code.GDPlayerSpriteObjects2= [];
gdjs.lvl2Code.GDPlayerSpriteObjects3= [];
gdjs.lvl2Code.GDNewSpriteObjects1= [];
gdjs.lvl2Code.GDNewSpriteObjects2= [];
gdjs.lvl2Code.GDNewSpriteObjects3= [];
gdjs.lvl2Code.GDCollisionBlockObjects1= [];
gdjs.lvl2Code.GDCollisionBlockObjects2= [];
gdjs.lvl2Code.GDCollisionBlockObjects3= [];
gdjs.lvl2Code.GDNewTileMapObjects1= [];
gdjs.lvl2Code.GDNewTileMapObjects2= [];
gdjs.lvl2Code.GDNewTileMapObjects3= [];
gdjs.lvl2Code.GDFrameInterfaceObjects1= [];
gdjs.lvl2Code.GDFrameInterfaceObjects2= [];
gdjs.lvl2Code.GDFrameInterfaceObjects3= [];
gdjs.lvl2Code.GDHPInterfaceObjects1= [];
gdjs.lvl2Code.GDHPInterfaceObjects2= [];
gdjs.lvl2Code.GDHPInterfaceObjects3= [];
gdjs.lvl2Code.GDScoreInterfaceObjects1= [];
gdjs.lvl2Code.GDScoreInterfaceObjects2= [];
gdjs.lvl2Code.GDScoreInterfaceObjects3= [];
gdjs.lvl2Code.GDKeyInterfaceObjects1= [];
gdjs.lvl2Code.GDKeyInterfaceObjects2= [];
gdjs.lvl2Code.GDKeyInterfaceObjects3= [];
gdjs.lvl2Code.GDHPTextObjects1= [];
gdjs.lvl2Code.GDHPTextObjects2= [];
gdjs.lvl2Code.GDHPTextObjects3= [];
gdjs.lvl2Code.GDScoreTextObjects1= [];
gdjs.lvl2Code.GDScoreTextObjects2= [];
gdjs.lvl2Code.GDScoreTextObjects3= [];
gdjs.lvl2Code.GDDoorObjects1= [];
gdjs.lvl2Code.GDDoorObjects2= [];
gdjs.lvl2Code.GDDoorObjects3= [];
gdjs.lvl2Code.GDKey2Objects1= [];
gdjs.lvl2Code.GDKey2Objects2= [];
gdjs.lvl2Code.GDKey2Objects3= [];
gdjs.lvl2Code.GDSpawnPointObjects1= [];
gdjs.lvl2Code.GDSpawnPointObjects2= [];
gdjs.lvl2Code.GDSpawnPointObjects3= [];
gdjs.lvl2Code.GDStartLvl1Objects1= [];
gdjs.lvl2Code.GDStartLvl1Objects2= [];
gdjs.lvl2Code.GDStartLvl1Objects3= [];
gdjs.lvl2Code.GDStartLvl2Objects1= [];
gdjs.lvl2Code.GDStartLvl2Objects2= [];
gdjs.lvl2Code.GDStartLvl2Objects3= [];
gdjs.lvl2Code.GDStartLvl3Objects1= [];
gdjs.lvl2Code.GDStartLvl3Objects2= [];
gdjs.lvl2Code.GDStartLvl3Objects3= [];
gdjs.lvl2Code.GD_9595_9595_9595Objects1= [];
gdjs.lvl2Code.GD_9595_9595_9595Objects2= [];
gdjs.lvl2Code.GD_9595_9595_9595Objects3= [];
gdjs.lvl2Code.GD_9595_9595_95952Objects1= [];
gdjs.lvl2Code.GD_9595_9595_95952Objects2= [];
gdjs.lvl2Code.GD_9595_9595_95952Objects3= [];


gdjs.lvl2Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].setAnimationFrame(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].setAnimationFrame(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects1.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects1[k] = gdjs.lvl2Code.GDPlayerSpriteObjects1[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDPlayerSpriteObjects1 */
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects1.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


};gdjs.lvl2Code.asyncCallback11520612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl2Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects3);

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.lvl2Code.GDSpawnPointObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.lvl2Code.GDPlayerSpriteObjects3.length ;i < len;++i) {
    gdjs.lvl2Code.GDPlayerSpriteObjects3[i].setPosition((( gdjs.lvl2Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl2Code.GDSpawnPointObjects3[0].getPointX("")),(( gdjs.lvl2Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl2Code.GDSpawnPointObjects3[0].getPointY("")));
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-mechanical-crate-pick-up-3154.wav", false, 100, 1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-casino-bling-achievement-2067.wav", false, 100, 1);
}
gdjs.lvl2Code.localVariables.length = 0;
}
gdjs.lvl2Code.idToCallbackMap.set(11520612, gdjs.lvl2Code.asyncCallback11520612);
gdjs.lvl2Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl2Code.localVariables);
for (const obj of gdjs.lvl2Code.GDPlayerSpriteObjects2) asyncObjectsList.addObject("PlayerSprite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.lvl2Code.asyncCallback11520612(runtimeScene, asyncObjectsList)), 11520612, asyncObjectsList);
}
}

}


};gdjs.lvl2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11520068);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl2Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.lvl2Code.asyncCallback11522684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl2Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}
gdjs.lvl2Code.localVariables.length = 0;
}
gdjs.lvl2Code.idToCallbackMap.set(11522684, gdjs.lvl2Code.asyncCallback11522684);
gdjs.lvl2Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.lvl2Code.asyncCallback11522684(runtimeScene, asyncObjectsList)), 11522684, asyncObjectsList);
}
}

}


};gdjs.lvl2Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDPlayerSpriteObjects2[i].getY() > 355 ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDPlayerSpriteObjects2[k] = gdjs.lvl2Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-player-losing-or-failing-2042.wav", false, 100, 1);
}

{ //Subevents
gdjs.lvl2Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl2Code.GDPlayerSpriteObjects2});
gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDScoreInterfaceObjects2Objects = Hashtable.newFrom({"ScoreInterface": gdjs.lvl2Code.GDScoreInterfaceObjects2});
gdjs.lvl2Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreInterface"), gdjs.lvl2Code.GDScoreInterfaceObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDScoreInterfaceObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDScoreInterfaceObjects2 */
{for(var i = 0, len = gdjs.lvl2Code.GDScoreInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDScoreInterfaceObjects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-winning-a-coin-video-game-2069.wav", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-video-game-health-recharge-2837.wav", false, 100, 1);
}
}

}


};gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl2Code.GDPlayerSpriteObjects2});
gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDKey2Objects2Objects = Hashtable.newFrom({"Key2": gdjs.lvl2Code.GDKey2Objects2});
gdjs.lvl2Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11528692);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(true);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 100, 1);
}
}

}


};gdjs.lvl2Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl2Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDKey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl2Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl2Code.GDKeyInterfaceObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);
{for(var i = 0, len = gdjs.lvl2Code.GDKey2Objects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDKey2Objects2[i].setPosition((( gdjs.lvl2Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl2Code.GDPlayerSpriteObjects2[0].getCenterXInScene()) - 8,(( gdjs.lvl2Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl2Code.GDPlayerSpriteObjects2[0].getCenterYInScene()) - 4);
}
}
{for(var i = 0, len = gdjs.lvl2Code.GDKeyInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl2Code.GDKeyInterfaceObjects2[i].setColor("255;255;255");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11530828);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl2Code.GDKeyInterfaceObjects1);
{for(var i = 0, len = gdjs.lvl2Code.GDKeyInterfaceObjects1.length ;i < len;++i) {
    gdjs.lvl2Code.GDKeyInterfaceObjects1[i].setColor("35;35;46");
}
}
}

}


};gdjs.lvl2Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.lvl2Code.GDPlayerSpriteObjects2.length !== 0 ? gdjs.lvl2Code.GDPlayerSpriteObjects2[0] : null), true, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, -476, 80, 1434, 355, "", 0);
}
}

}


};gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects1Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl2Code.GDPlayerSpriteObjects1});
gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.lvl2Code.GDDoorObjects1});
gdjs.lvl2Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.lvl2Code.GDDoorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl2Code.GDDoorObjects1.length;i<l;++i) {
    if ( gdjs.lvl2Code.GDDoorObjects1[i].getBehavior("Animation").getAnimationName() == "Opened" ) {
        isConditionTrue_0 = true;
        gdjs.lvl2Code.GDDoorObjects1[k] = gdjs.lvl2Code.GDDoorObjects1[i];
        ++k;
    }
}
gdjs.lvl2Code.GDDoorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl3", false);
}
}

}


};gdjs.lvl2Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11285788);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UserInterface", 0, 0, 0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "inono777-game-8-bit-399898.mp3", true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}
}

}


{


gdjs.lvl2Code.eventsList0(runtimeScene);
}


{


gdjs.lvl2Code.eventsList4(runtimeScene);
}


{


gdjs.lvl2Code.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HPText"), gdjs.lvl2Code.GDHPTextObjects1);
{for(var i = 0, len = gdjs.lvl2Code.GDHPTextObjects1.length ;i < len;++i) {
    gdjs.lvl2Code.GDHPTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.lvl2Code.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.lvl2Code.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.lvl2Code.GDScoreTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


gdjs.lvl2Code.eventsList7(runtimeScene);
}


{


gdjs.lvl2Code.eventsList8(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.lvl2Code.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl2Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDPlayerSpriteObjects1Objects, gdjs.lvl2Code.mapOfGDgdjs_9546lvl2Code_9546GDDoorObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl2Code.GDDoorObjects1 */
{for(var i = 0, len = gdjs.lvl2Code.GDDoorObjects1.length ;i < len;++i) {
    gdjs.lvl2Code.GDDoorObjects1[i].getBehavior("Animation").setAnimationName("Opened");
}
}

{ //Subevents
gdjs.lvl2Code.eventsList9(runtimeScene);} //End of subevents
}

}


};

gdjs.lvl2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl2Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl2Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDHPTextObjects1.length = 0;
gdjs.lvl2Code.GDHPTextObjects2.length = 0;
gdjs.lvl2Code.GDHPTextObjects3.length = 0;
gdjs.lvl2Code.GDScoreTextObjects1.length = 0;
gdjs.lvl2Code.GDScoreTextObjects2.length = 0;
gdjs.lvl2Code.GDScoreTextObjects3.length = 0;
gdjs.lvl2Code.GDDoorObjects1.length = 0;
gdjs.lvl2Code.GDDoorObjects2.length = 0;
gdjs.lvl2Code.GDDoorObjects3.length = 0;
gdjs.lvl2Code.GDKey2Objects1.length = 0;
gdjs.lvl2Code.GDKey2Objects2.length = 0;
gdjs.lvl2Code.GDKey2Objects3.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects3.length = 0;

gdjs.lvl2Code.eventsList10(runtimeScene);
gdjs.lvl2Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl2Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl2Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl2Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl2Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl2Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl2Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl2Code.GDHPTextObjects1.length = 0;
gdjs.lvl2Code.GDHPTextObjects2.length = 0;
gdjs.lvl2Code.GDHPTextObjects3.length = 0;
gdjs.lvl2Code.GDScoreTextObjects1.length = 0;
gdjs.lvl2Code.GDScoreTextObjects2.length = 0;
gdjs.lvl2Code.GDScoreTextObjects3.length = 0;
gdjs.lvl2Code.GDDoorObjects1.length = 0;
gdjs.lvl2Code.GDDoorObjects2.length = 0;
gdjs.lvl2Code.GDDoorObjects3.length = 0;
gdjs.lvl2Code.GDKey2Objects1.length = 0;
gdjs.lvl2Code.GDKey2Objects2.length = 0;
gdjs.lvl2Code.GDKey2Objects3.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl2Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl2Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl2Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl2Code.GD_9595_9595_95952Objects3.length = 0;


return;

}

gdjs['lvl2Code'] = gdjs.lvl2Code;
