gdjs.GameOverCode = {};
gdjs.GameOverCode.localVariables = [];
gdjs.GameOverCode.idToCallbackMap = new Map();
gdjs.GameOverCode.GDNewTextObjects1= [];
gdjs.GameOverCode.GDNewTextObjects2= [];
gdjs.GameOverCode.GDNewTextObjects3= [];
gdjs.GameOverCode.GDPlayerSpriteObjects1= [];
gdjs.GameOverCode.GDPlayerSpriteObjects2= [];
gdjs.GameOverCode.GDPlayerSpriteObjects3= [];
gdjs.GameOverCode.GDNewSpriteObjects1= [];
gdjs.GameOverCode.GDNewSpriteObjects2= [];
gdjs.GameOverCode.GDNewSpriteObjects3= [];
gdjs.GameOverCode.GDCollisionBlockObjects1= [];
gdjs.GameOverCode.GDCollisionBlockObjects2= [];
gdjs.GameOverCode.GDCollisionBlockObjects3= [];
gdjs.GameOverCode.GDNewTileMapObjects1= [];
gdjs.GameOverCode.GDNewTileMapObjects2= [];
gdjs.GameOverCode.GDNewTileMapObjects3= [];
gdjs.GameOverCode.GDFrameInterfaceObjects1= [];
gdjs.GameOverCode.GDFrameInterfaceObjects2= [];
gdjs.GameOverCode.GDFrameInterfaceObjects3= [];
gdjs.GameOverCode.GDHPInterfaceObjects1= [];
gdjs.GameOverCode.GDHPInterfaceObjects2= [];
gdjs.GameOverCode.GDHPInterfaceObjects3= [];
gdjs.GameOverCode.GDScoreInterfaceObjects1= [];
gdjs.GameOverCode.GDScoreInterfaceObjects2= [];
gdjs.GameOverCode.GDScoreInterfaceObjects3= [];
gdjs.GameOverCode.GDKeyInterfaceObjects1= [];
gdjs.GameOverCode.GDKeyInterfaceObjects2= [];
gdjs.GameOverCode.GDKeyInterfaceObjects3= [];
gdjs.GameOverCode.GDHPTextObjects1= [];
gdjs.GameOverCode.GDHPTextObjects2= [];
gdjs.GameOverCode.GDHPTextObjects3= [];
gdjs.GameOverCode.GDScoreTextObjects1= [];
gdjs.GameOverCode.GDScoreTextObjects2= [];
gdjs.GameOverCode.GDScoreTextObjects3= [];
gdjs.GameOverCode.GDDoorObjects1= [];
gdjs.GameOverCode.GDDoorObjects2= [];
gdjs.GameOverCode.GDDoorObjects3= [];
gdjs.GameOverCode.GDKey2Objects1= [];
gdjs.GameOverCode.GDKey2Objects2= [];
gdjs.GameOverCode.GDKey2Objects3= [];
gdjs.GameOverCode.GDSpawnPointObjects1= [];
gdjs.GameOverCode.GDSpawnPointObjects2= [];
gdjs.GameOverCode.GDSpawnPointObjects3= [];
gdjs.GameOverCode.GDStartLvl1Objects1= [];
gdjs.GameOverCode.GDStartLvl1Objects2= [];
gdjs.GameOverCode.GDStartLvl1Objects3= [];
gdjs.GameOverCode.GDStartLvl2Objects1= [];
gdjs.GameOverCode.GDStartLvl2Objects2= [];
gdjs.GameOverCode.GDStartLvl2Objects3= [];
gdjs.GameOverCode.GDStartLvl3Objects1= [];
gdjs.GameOverCode.GDStartLvl3Objects2= [];
gdjs.GameOverCode.GDStartLvl3Objects3= [];
gdjs.GameOverCode.GD_9595_9595_9595Objects1= [];
gdjs.GameOverCode.GD_9595_9595_9595Objects2= [];
gdjs.GameOverCode.GD_9595_9595_9595Objects3= [];
gdjs.GameOverCode.GD_9595_9595_95952Objects1= [];
gdjs.GameOverCode.GD_9595_9595_95952Objects2= [];
gdjs.GameOverCode.GD_9595_9595_95952Objects3= [];


gdjs.GameOverCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
}

}


};gdjs.GameOverCode.asyncCallback11408468 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameOverCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "InitialMenu", false);
}

{ //Subevents
gdjs.GameOverCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.GameOverCode.localVariables.length = 0;
}
gdjs.GameOverCode.idToCallbackMap.set(11408468, gdjs.GameOverCode.asyncCallback11408468);
gdjs.GameOverCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameOverCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameOverCode.asyncCallback11408468(runtimeScene, asyncObjectsList)), 11408468, asyncObjectsList);
}
}

}


};gdjs.GameOverCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameOverCode.eventsList1(runtimeScene);} //End of subevents
}

}


};

gdjs.GameOverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameOverCode.GDNewTextObjects1.length = 0;
gdjs.GameOverCode.GDNewTextObjects2.length = 0;
gdjs.GameOverCode.GDNewTextObjects3.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects1.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects2.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects3.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects1.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects2.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects3.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects1.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects2.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects3.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects1.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects2.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects3.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDHPTextObjects1.length = 0;
gdjs.GameOverCode.GDHPTextObjects2.length = 0;
gdjs.GameOverCode.GDHPTextObjects3.length = 0;
gdjs.GameOverCode.GDScoreTextObjects1.length = 0;
gdjs.GameOverCode.GDScoreTextObjects2.length = 0;
gdjs.GameOverCode.GDScoreTextObjects3.length = 0;
gdjs.GameOverCode.GDDoorObjects1.length = 0;
gdjs.GameOverCode.GDDoorObjects2.length = 0;
gdjs.GameOverCode.GDDoorObjects3.length = 0;
gdjs.GameOverCode.GDKey2Objects1.length = 0;
gdjs.GameOverCode.GDKey2Objects2.length = 0;
gdjs.GameOverCode.GDKey2Objects3.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects1.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects2.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects3.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects3.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects3.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects3.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects3.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects2.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects3.length = 0;

gdjs.GameOverCode.eventsList2(runtimeScene);
gdjs.GameOverCode.GDNewTextObjects1.length = 0;
gdjs.GameOverCode.GDNewTextObjects2.length = 0;
gdjs.GameOverCode.GDNewTextObjects3.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects1.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects2.length = 0;
gdjs.GameOverCode.GDPlayerSpriteObjects3.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects1.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects2.length = 0;
gdjs.GameOverCode.GDNewSpriteObjects3.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects1.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects2.length = 0;
gdjs.GameOverCode.GDCollisionBlockObjects3.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects1.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects2.length = 0;
gdjs.GameOverCode.GDNewTileMapObjects3.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDFrameInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDHPInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDScoreInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects1.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects2.length = 0;
gdjs.GameOverCode.GDKeyInterfaceObjects3.length = 0;
gdjs.GameOverCode.GDHPTextObjects1.length = 0;
gdjs.GameOverCode.GDHPTextObjects2.length = 0;
gdjs.GameOverCode.GDHPTextObjects3.length = 0;
gdjs.GameOverCode.GDScoreTextObjects1.length = 0;
gdjs.GameOverCode.GDScoreTextObjects2.length = 0;
gdjs.GameOverCode.GDScoreTextObjects3.length = 0;
gdjs.GameOverCode.GDDoorObjects1.length = 0;
gdjs.GameOverCode.GDDoorObjects2.length = 0;
gdjs.GameOverCode.GDDoorObjects3.length = 0;
gdjs.GameOverCode.GDKey2Objects1.length = 0;
gdjs.GameOverCode.GDKey2Objects2.length = 0;
gdjs.GameOverCode.GDKey2Objects3.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects1.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects2.length = 0;
gdjs.GameOverCode.GDSpawnPointObjects3.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl1Objects3.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl2Objects3.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects1.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects2.length = 0;
gdjs.GameOverCode.GDStartLvl3Objects3.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects1.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects2.length = 0;
gdjs.GameOverCode.GD_9595_9595_9595Objects3.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects1.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects2.length = 0;
gdjs.GameOverCode.GD_9595_9595_95952Objects3.length = 0;


return;

}

gdjs['GameOverCode'] = gdjs.GameOverCode;
