gdjs.lvl4Code = {};
gdjs.lvl4Code.localVariables = [];
gdjs.lvl4Code.idToCallbackMap = new Map();
gdjs.lvl4Code.GDNewTextObjects1= [];
gdjs.lvl4Code.GDNewTextObjects2= [];
gdjs.lvl4Code.GDNewTextObjects3= [];
gdjs.lvl4Code.GDPlayerSpriteObjects1= [];
gdjs.lvl4Code.GDPlayerSpriteObjects2= [];
gdjs.lvl4Code.GDPlayerSpriteObjects3= [];
gdjs.lvl4Code.GDNewSpriteObjects1= [];
gdjs.lvl4Code.GDNewSpriteObjects2= [];
gdjs.lvl4Code.GDNewSpriteObjects3= [];
gdjs.lvl4Code.GDCollisionBlockObjects1= [];
gdjs.lvl4Code.GDCollisionBlockObjects2= [];
gdjs.lvl4Code.GDCollisionBlockObjects3= [];
gdjs.lvl4Code.GDNewTileMapObjects1= [];
gdjs.lvl4Code.GDNewTileMapObjects2= [];
gdjs.lvl4Code.GDNewTileMapObjects3= [];
gdjs.lvl4Code.GDFrameInterfaceObjects1= [];
gdjs.lvl4Code.GDFrameInterfaceObjects2= [];
gdjs.lvl4Code.GDFrameInterfaceObjects3= [];
gdjs.lvl4Code.GDHPInterfaceObjects1= [];
gdjs.lvl4Code.GDHPInterfaceObjects2= [];
gdjs.lvl4Code.GDHPInterfaceObjects3= [];
gdjs.lvl4Code.GDScoreInterfaceObjects1= [];
gdjs.lvl4Code.GDScoreInterfaceObjects2= [];
gdjs.lvl4Code.GDScoreInterfaceObjects3= [];
gdjs.lvl4Code.GDKeyInterfaceObjects1= [];
gdjs.lvl4Code.GDKeyInterfaceObjects2= [];
gdjs.lvl4Code.GDKeyInterfaceObjects3= [];
gdjs.lvl4Code.GDHPTextObjects1= [];
gdjs.lvl4Code.GDHPTextObjects2= [];
gdjs.lvl4Code.GDHPTextObjects3= [];
gdjs.lvl4Code.GDScoreTextObjects1= [];
gdjs.lvl4Code.GDScoreTextObjects2= [];
gdjs.lvl4Code.GDScoreTextObjects3= [];
gdjs.lvl4Code.GDDoorObjects1= [];
gdjs.lvl4Code.GDDoorObjects2= [];
gdjs.lvl4Code.GDDoorObjects3= [];
gdjs.lvl4Code.GDKey2Objects1= [];
gdjs.lvl4Code.GDKey2Objects2= [];
gdjs.lvl4Code.GDKey2Objects3= [];
gdjs.lvl4Code.GDSpawnPointObjects1= [];
gdjs.lvl4Code.GDSpawnPointObjects2= [];
gdjs.lvl4Code.GDSpawnPointObjects3= [];
gdjs.lvl4Code.GDStartLvl1Objects1= [];
gdjs.lvl4Code.GDStartLvl1Objects2= [];
gdjs.lvl4Code.GDStartLvl1Objects3= [];
gdjs.lvl4Code.GDStartLvl2Objects1= [];
gdjs.lvl4Code.GDStartLvl2Objects2= [];
gdjs.lvl4Code.GDStartLvl2Objects3= [];
gdjs.lvl4Code.GDStartLvl3Objects1= [];
gdjs.lvl4Code.GDStartLvl3Objects2= [];
gdjs.lvl4Code.GDStartLvl3Objects3= [];
gdjs.lvl4Code.GD_9595_9595_9595Objects1= [];
gdjs.lvl4Code.GD_9595_9595_9595Objects2= [];
gdjs.lvl4Code.GD_9595_9595_9595Objects3= [];
gdjs.lvl4Code.GD_9595_9595_95952Objects1= [];
gdjs.lvl4Code.GD_9595_9595_95952Objects2= [];
gdjs.lvl4Code.GD_9595_9595_95952Objects3= [];


gdjs.lvl4Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Walk");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].setAnimationFrame(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].setAnimationFrame(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects1.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects1[k] = gdjs.lvl4Code.GDPlayerSpriteObjects1[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDPlayerSpriteObjects1 */
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


};gdjs.lvl4Code.asyncCallback11520612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl4Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects3);

gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.lvl4Code.GDSpawnPointObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{for(var i = 0, len = gdjs.lvl4Code.GDPlayerSpriteObjects3.length ;i < len;++i) {
    gdjs.lvl4Code.GDPlayerSpriteObjects3[i].setPosition((( gdjs.lvl4Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl4Code.GDSpawnPointObjects3[0].getPointX("")),(( gdjs.lvl4Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.lvl4Code.GDSpawnPointObjects3[0].getPointY("")));
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-mechanical-crate-pick-up-3154.wav", false, 100, 1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-casino-bling-achievement-2067.wav", false, 100, 1);
}
gdjs.lvl4Code.localVariables.length = 0;
}
gdjs.lvl4Code.idToCallbackMap.set(11520612, gdjs.lvl4Code.asyncCallback11520612);
gdjs.lvl4Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl4Code.localVariables);
for (const obj of gdjs.lvl4Code.GDPlayerSpriteObjects2) asyncObjectsList.addObject("PlayerSprite", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.lvl4Code.asyncCallback11520612(runtimeScene, asyncObjectsList)), 11520612, asyncObjectsList);
}
}

}


};gdjs.lvl4Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11520068);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl4Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.lvl4Code.asyncCallback11522684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvl4Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}
gdjs.lvl4Code.localVariables.length = 0;
}
gdjs.lvl4Code.idToCallbackMap.set(11522684, gdjs.lvl4Code.asyncCallback11522684);
gdjs.lvl4Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvl4Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.lvl4Code.asyncCallback11522684(runtimeScene, asyncObjectsList)), 11522684, asyncObjectsList);
}
}

}


};gdjs.lvl4Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDPlayerSpriteObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDPlayerSpriteObjects2[i].getY() > 355 ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDPlayerSpriteObjects2[k] = gdjs.lvl4Code.GDPlayerSpriteObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl4Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-player-losing-or-failing-2042.wav", false, 100, 1);
}

{ //Subevents
gdjs.lvl4Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl4Code.GDPlayerSpriteObjects2});
gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDScoreInterfaceObjects2Objects = Hashtable.newFrom({"ScoreInterface": gdjs.lvl4Code.GDScoreInterfaceObjects2});
gdjs.lvl4Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreInterface"), gdjs.lvl4Code.GDScoreInterfaceObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDScoreInterfaceObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDScoreInterfaceObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDScoreInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDScoreInterfaceObjects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-winning-a-coin-video-game-2069.wav", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() >= 5);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-video-game-health-recharge-2837.wav", false, 100, 1);
}
}

}


};gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects2Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl4Code.GDPlayerSpriteObjects2});
gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDKey2Objects2Objects = Hashtable.newFrom({"Key2": gdjs.lvl4Code.GDKey2Objects2});
gdjs.lvl4Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11528692);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(true);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 100, 1);
}
}

}


};gdjs.lvl4Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl4Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects2Objects, gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDKey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl4Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Key2"), gdjs.lvl4Code.GDKey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl4Code.GDKeyInterfaceObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDKey2Objects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDKey2Objects2[i].setPosition((( gdjs.lvl4Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl4Code.GDPlayerSpriteObjects2[0].getCenterXInScene()) - 8,(( gdjs.lvl4Code.GDPlayerSpriteObjects2.length === 0 ) ? 0 :gdjs.lvl4Code.GDPlayerSpriteObjects2[0].getCenterYInScene()) - 4);
}
}
{for(var i = 0, len = gdjs.lvl4Code.GDKeyInterfaceObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDKeyInterfaceObjects2[i].setColor("255;255;255");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11530828);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("KeyInterface"), gdjs.lvl4Code.GDKeyInterfaceObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDKeyInterfaceObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDKeyInterfaceObjects1[i].setColor("35;35;46");
}
}
}

}


};gdjs.lvl4Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.lvl4Code.GDPlayerSpriteObjects2.length !== 0 ? gdjs.lvl4Code.GDPlayerSpriteObjects2[0] : null), true, "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, -476, 80, 1434, 355, "", 0);
}
}

}


};gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects1Objects = Hashtable.newFrom({"PlayerSprite": gdjs.lvl4Code.GDPlayerSpriteObjects1});
gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.lvl4Code.GDDoorObjects1});
gdjs.lvl4Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.lvl4Code.GDDoorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvl4Code.GDDoorObjects1.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDDoorObjects1[i].getBehavior("Animation").getAnimationName() == "Opened" ) {
        isConditionTrue_0 = true;
        gdjs.lvl4Code.GDDoorObjects1[k] = gdjs.lvl4Code.GDDoorObjects1[i];
        ++k;
    }
}
gdjs.lvl4Code.GDDoorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl5", false);
}
}

}


};gdjs.lvl4Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}
}

}


{


gdjs.lvl4Code.eventsList0(runtimeScene);
}


{


gdjs.lvl4Code.eventsList4(runtimeScene);
}


{


gdjs.lvl4Code.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HPText"), gdjs.lvl4Code.GDHPTextObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDHPTextObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDHPTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.lvl4Code.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDScoreTextObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


gdjs.lvl4Code.eventsList7(runtimeScene);
}


{


gdjs.lvl4Code.eventsList8(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11373860);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UserInterface", 0, 0, 0);
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "inono777-game-8-bit-399898.mp3", true, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.lvl4Code.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerSprite"), gdjs.lvl4Code.GDPlayerSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDPlayerSpriteObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_9546lvl4Code_9546GDDoorObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl4Code.GDDoorObjects1 */
{for(var i = 0, len = gdjs.lvl4Code.GDDoorObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDDoorObjects1[i].getBehavior("Animation").setAnimationName("Opened");
}
}

{ //Subevents
gdjs.lvl4Code.eventsList9(runtimeScene);} //End of subevents
}

}


};

gdjs.lvl4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl4Code.GDNewTextObjects1.length = 0;
gdjs.lvl4Code.GDNewTextObjects2.length = 0;
gdjs.lvl4Code.GDNewTextObjects3.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDHPTextObjects1.length = 0;
gdjs.lvl4Code.GDHPTextObjects2.length = 0;
gdjs.lvl4Code.GDHPTextObjects3.length = 0;
gdjs.lvl4Code.GDScoreTextObjects1.length = 0;
gdjs.lvl4Code.GDScoreTextObjects2.length = 0;
gdjs.lvl4Code.GDScoreTextObjects3.length = 0;
gdjs.lvl4Code.GDDoorObjects1.length = 0;
gdjs.lvl4Code.GDDoorObjects2.length = 0;
gdjs.lvl4Code.GDDoorObjects3.length = 0;
gdjs.lvl4Code.GDKey2Objects1.length = 0;
gdjs.lvl4Code.GDKey2Objects2.length = 0;
gdjs.lvl4Code.GDKey2Objects3.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects3.length = 0;

gdjs.lvl4Code.eventsList10(runtimeScene);
gdjs.lvl4Code.GDNewTextObjects1.length = 0;
gdjs.lvl4Code.GDNewTextObjects2.length = 0;
gdjs.lvl4Code.GDNewTextObjects3.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects1.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects2.length = 0;
gdjs.lvl4Code.GDPlayerSpriteObjects3.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects1.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects2.length = 0;
gdjs.lvl4Code.GDNewSpriteObjects3.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects1.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects2.length = 0;
gdjs.lvl4Code.GDCollisionBlockObjects3.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects1.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects2.length = 0;
gdjs.lvl4Code.GDNewTileMapObjects3.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDFrameInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDHPInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDScoreInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects1.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects2.length = 0;
gdjs.lvl4Code.GDKeyInterfaceObjects3.length = 0;
gdjs.lvl4Code.GDHPTextObjects1.length = 0;
gdjs.lvl4Code.GDHPTextObjects2.length = 0;
gdjs.lvl4Code.GDHPTextObjects3.length = 0;
gdjs.lvl4Code.GDScoreTextObjects1.length = 0;
gdjs.lvl4Code.GDScoreTextObjects2.length = 0;
gdjs.lvl4Code.GDScoreTextObjects3.length = 0;
gdjs.lvl4Code.GDDoorObjects1.length = 0;
gdjs.lvl4Code.GDDoorObjects2.length = 0;
gdjs.lvl4Code.GDDoorObjects3.length = 0;
gdjs.lvl4Code.GDKey2Objects1.length = 0;
gdjs.lvl4Code.GDKey2Objects2.length = 0;
gdjs.lvl4Code.GDKey2Objects3.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects1.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects2.length = 0;
gdjs.lvl4Code.GDSpawnPointObjects3.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl1Objects3.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl2Objects3.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects1.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects2.length = 0;
gdjs.lvl4Code.GDStartLvl3Objects3.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects1.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects2.length = 0;
gdjs.lvl4Code.GD_9595_9595_9595Objects3.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects1.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects2.length = 0;
gdjs.lvl4Code.GD_9595_9595_95952Objects3.length = 0;


return;

}

gdjs['lvl4Code'] = gdjs.lvl4Code;
